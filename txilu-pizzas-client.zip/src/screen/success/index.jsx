import { Text, View } from "react-native"

const Success = () => {
    return (
        <View>
            <Text>
                Succsess!
            </Text>
        </View>
    )
}

export default Success