import { Text, View } from "react-native"

export default Main = () => {
    return (
        <View>
            <Text >
                Main
            </Text>
        </View>
    )
}